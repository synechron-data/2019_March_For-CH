// import './1_Types/1_ES5_Properties';
// import './1_Types/2_ES6_Properties';
// import './1_Types/3_ES5_Inheritance';
// import './1_Types/4_ES6_Inheritance';

// import './2_Collections/1_Arrays';
// import './2_Collections/2_Map';
// import './2_Collections/3_WeakMap';
// import './2_Collections/4_Set';

// import './3_NewTypes/1_Symbol';
// import './3_NewTypes/2_CustomCollection';
// import './3_NewTypes/3_Generators';

// import './4_Promise/1_CustomPromise';
import LocalAPI from './4_Promise/LocalApi';

(async function () {
    var data = await LocalAPI.getPosts();
    console.log(data);
    console.log("End of Code....");
})();