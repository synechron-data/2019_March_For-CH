class MyCollection {
    constructor() {
        this._dataArray = [];
    }

    add(data) {
        this._dataArray.push(data);
    }

    *[Symbol.iterator]() {
        yield* this._dataArray;
    }

    // *[Symbol.iterator]() { 
    //     for (let i = 0; i < this._dataArray.length; i++) {
    //         yield this._dataArray[i];
    //     }
    // }

    // [Symbol.iterator]() {
    //     const self = this;
    //     let i = 0;

    //     return {
    //         next: function () {
    //             let v, d = true;

    //             if (self._dataArray[i] !== undefined) {
    //                 v = self._dataArray[i];
    //                 d = false;
    //                 i += 1;
    //             }

    //             return {
    //                 value: v,
    //                 done: d
    //             };
    //         }
    //     };
    // }
}

var arr = new MyCollection();
// arr.add(10);
// arr.add(20);
// arr.add(30);
// arr.add(40);
// arr.add(50);

arr.add({ id: 1, name: "Manish1" });
arr.add({ id: 2, name: "Manish2" });
arr.add({ id: 3, name: "Manish3" });
arr.add({ id: 4, name: "Manish4" });

// console.log(arr);

// for (const item of arr) {
//     console.log(item);
// }

// Customer Iterator
// let makeIterator = function (arr) {
//     let current = 0;
//     return {
//         next: function () {
//             return current < arr.length ? {
//                 value: arr[current++],
//                 done: false
//             } : {
//                     done: true
//                 };
//         }
//     };
// }

// var numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9];

// let numberIterator = makeIterator(numbers);

// while (true) {
//     let { value, done } = numberIterator.next();
//     if (done) break;
//     console.log(value);
// }

function* idGenerator() {
    let index = 0;
    while (index < 345) {
        yield index++;
    }
}

console.log([...idGenerator()]);