// var set = new Set();

// set.add(1);
// set.add(2);
// set.add(3);
// set.add(4);
// set.add(4);

// for (const item of set) {
//     console.log(item);
// }

var set = new Set();

var mohan = { id: 4, name: "Mohan" };

set.add({ id: 1, name: "Manish" });
set.add({ id: 2, name: "Pedro" });
set.add({ id: 3, name: "Manoj" });
set.add(mohan);
set.add(mohan);

for (const item of set) {
    console.log(item);
}