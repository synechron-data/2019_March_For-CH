// var employees = new Array();
// var employees = new Array(2);
// var employees = [];
// console.log(employees.length);

// var employees = new Array(2);

// employees[0] = "Manish";
// employees[1] = "Abhijeet";
// employees[2] = "Ramakant";
// employees[8] = "Subodh";

// for (let i = 0; i < employees.length; i++) {
//     console.log(i + "\t" + employees[i]);
// }

var employees = [
    { id: 1, name: "Manish" },
    { id: 2, name: "Varun" },
    { id: 3, name: "Paresh" },
    { id: 4, name: "Devesh" },
    { id: 5, name: "Atul" },
];

// for (let i = 0; i < employees.length; i++) {
//     // console.log(i + "\t" + JSON.stringify(employees[i]));
//     console.log(i + "\t" + employees[i].id + "\t" + employees[i].name);
// }

// console.log(typeof employees);

// for (const key in employees) {
//     console.log(key + "\t" + employees[key].id + "\t" + employees[key].name);
// }

// employees.forEach((item, index, arr) => {
//     console.log(arr);
//     console.log(index + "\t" + item.id + "\t" + item.name);
// });

// ES2015 - ForOf Loop
// for (const item of employees) {
//     console.log(item.id + "\t" + item.name);
// }

// var result = employees.filter((emp) => emp.id == 4);
// console.log(result[0]);

// var result = employees.find((emp) => emp.id == 4);
// console.log(result);

var states = new Array();

states["GA"] = "Goa";
states["MH"] = "Maharashtra";
states["DL"] = "Delhi";

for (const key in states) {
    console.log(key + "\t" + states[key]);
}