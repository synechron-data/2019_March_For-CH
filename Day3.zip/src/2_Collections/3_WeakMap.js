// var wMap = new WeakMap();

// var o1 = {};
// var o2 = window;

// wMap.set(o1, "Hello There");
// wMap.set(o2, "This is the window object");

// for (const pair of wMap) {
//     console.log(pair);
// }

// console.log(wMap.get(o1));
// console.log(wMap.get(o2));

var map = new Map();
var wmap = new WeakMap();

// var a = { a: 1 };
// var b = { b: 2 };

// map.set(a, "This is Map");
// wmap.set(b, "This is Weak Map");

(function () {
    var a = { a: 1 };
    var b = { b: 2 };

    map.set(a, "This is Map");
    wmap.set(b, "This is Weak Map");
})();