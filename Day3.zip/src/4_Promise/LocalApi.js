class LocalAPI {
    static getAllPosts(successCB, errorCB) {
        fetch('https://jsonplaceholder.typicode.com/posts').then((response) => {
            var result = response.json();
            result.then(data => {
                successCB(data);
            }).catch(err => {
                errorCB("JSON Parse Error...");
            })
        }, (err) => {
            errorCB("Communication Error...");
        });
    }

    static getAllPostsUsingPromise() {
        var promise = new Promise((resolve, reject) => {
            fetch('https://jsonplaceholder.typicode.com/posts').then((response) => {
                var result = response.json();
                result.then(data => {
                    resolve(data);
                }).catch(err => {
                    // Log the actual Error
                    reject("JSON Parse Error...");
                })
            }, (err) => {
                // Log the actual Error
                reject("Communication Error...");
            });
        });

        return promise;
    }

    static async getPosts() {
        var response = await fetch('https://jsonplaceholder.typicode.com/posts');
        var data = await response.json();
        return data;
    }
}

export default LocalAPI;