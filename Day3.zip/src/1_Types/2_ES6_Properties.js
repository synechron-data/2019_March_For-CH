class Employee {
    constructor(n, a) {
        this._name = n;
        this._age = a;
    }

    get Name() {
        return this._name;
    }

    set Name(value) {
        if (!value)
            throw Error("Name cannot be empty.");
        this._name = value;
    }

    get Age() {
        return this._age;
    }

    set Age(value) {
        if (value < 0)
            throw Error("Age cannot be negative.");
        this._age = value;
    }
}

var e1 = new Employee("Manish", 20);
console.log(e1.Name);      // Get
console.log(e1.Age);

e1.Name = "Abhijeet";      // Set
e1.Age = 30;

console.log(e1.Name);
console.log(e1.Age);
