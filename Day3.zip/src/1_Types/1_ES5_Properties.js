// function Employee(n) {
//     // this._name = n;
// }

// Object.defineProperty(Employee.prototype, "firstName", {
//     value: "Not Set",
//     writable: true
// });

// var e1 = new Employee("Manish");
// console.log(e1.firstName);      // Get
// e1.firstName = "Abhijeet";      // Set
// console.log(e1.firstName);

// ----------------------------------------------------- Accessor Method

// var Employee = (function () {
//     function Employee(n) {
//         this._name = n;
//     }

//     Employee.prototype.setName = function (value) {
//         if(!value)
//             throw Error("Name cannot be empty.");
//         this._name = value;
//     };

//     Employee.prototype.getName = function () {
//         return this._name;
//     }
//     return Employee;
// })();

// var e1 = new Employee("Manish");
// // e1._name = "";
// console.log("Name: ", e1.getName());      // Get
// e1.setName("Abhijeet");                   // Set
// console.log("Name: ", e1.getName());


// ----------------------------------------------------- Properties
var Employee = (function () {
    function Employee(n, a) {
        this._name = n;
        _age = a;
    }

    Object.defineProperty(Employee.prototype, "Name", {
        set: function (value) {
            if (!value)
                throw Error("Name cannot be empty.");
            this._name = value;
        },
        get: function () {
            return this._name;
        }
    });

    var _age;

    Object.defineProperty(Employee.prototype, "Age", {
        set: function (value) {
            if (value < 0)
                throw Error("Age cannot be negative.");
            _age = value;
        },
        get: function () {
            return _age;
        }
    });

    return Employee;
})();

var e1 = new Employee("Manish", 20);
console.log(e1.Name);      // Get
e1.Name = "Abhijeet";      // Set
console.log(e1.Name);
console.log(e1.Age);
e1.Age = 30;
console.log(e1.Age);
// console.log("Name: ", e1._name);
// console.log("Age: ", e1._age);
