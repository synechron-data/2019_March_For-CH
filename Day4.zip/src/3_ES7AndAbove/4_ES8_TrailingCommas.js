// In ES6, following is already allowed
// var arr = [10,20,30,40,];
// console.log(arr);

// let person = {id:1,name:"Manish",};
// console.log(person);

// ES8
var fn = function (a, b, ) {
    console.log(a, b);
}

console.log(fn);
fn(23, 45, 56);
