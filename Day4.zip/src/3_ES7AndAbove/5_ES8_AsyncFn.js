var firstMethodUsingPromise = function () {
    var promise = new Promise((resolve, reject) => {
        setTimeout(function () {
            resolve({ data: 1 });
        }, 2000);
    });

    return promise;
}

var firstMethod = async function () {
    return ({ data: 1 });
}

export default firstMethod;