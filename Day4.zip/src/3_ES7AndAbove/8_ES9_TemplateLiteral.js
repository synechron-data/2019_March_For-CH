// Tagged Template Literals
// function tagFunc(tmplObj) {
//     console.log(tmplObj);
//     return {
//         Cooked: tmplObj,
//         Raw: tmplObj.raw
//     }
// }

function tagFunc(strings, exp) {
    // console.log(strings);
    return exp + " " + strings[0] + strings[1];
}

var name = "Manish";
console.log(`Hello ${name} How are you`);
console.log(tagFunc`Hello ${name} How are you`);