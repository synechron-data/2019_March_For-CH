// let result = Math.pow(2, 4);
// console.log(result);

// Exponentiation Operator
// let result = 2 ** 4;
// debugger;
// console.log(result);

// -------------------------------------------------- Array Includes
let arr = ["ReactJS", "Angular", "ExtJS"];

// console.log(arr.indexOf('ReactJS'));
// console.log(Boolean(arr.indexOf('ReactJS')));

// if (arr.indexOf('ReactJS')) {
//     console.log("React is available...");
// } else {
//     console.log("React is not available...");
// }

// console.log(arr.indexOf('Vue'));
// console.log(Boolean(arr.indexOf('Vue')));

// if (arr.indexOf('Vue')) {
//     console.log("Vue is available...");
// } else {
//     console.log("Vue is not available...");
// }

// if (arr.indexOf('ReactJS') !== -1) {
//     console.log("React is available...");
// } else {
//     console.log("React is not available...");
// }

// ES7
if (arr.includes('ReactJS')) {
    console.log("React is available...");
} else {
    console.log("React is not available...");
}
