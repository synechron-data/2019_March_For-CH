// Object.prototype.objFunc = function () {

// }

// // Array.prototype.myFunc = function () {
// //     console.log("Custom Function on Array Prototype");
// // }

// // let numbers = [10, 20, 30];

// // for (const key in numbers) {
// //     console.log(key, numbers[key]);
// // }

// // for (const key in numbers) {
// //     if (numbers.hasOwnProperty(key)) {
// //         console.log(key, numbers[key]);
// //     }
// // }

// // Object.keys(numbers).forEach((key, index) => {
// //     console.log(key, numbers[key]);
// // });

// var person = { id: 1, name: "Manish" };

// // Object.keys(person).forEach((key, index) => {
// //     console.log(key, person[key]);
// // });

// // ES2015
// for (const key of Object.keys(person)) {
//     console.log(key, person[key]);
// }

// --------------------------------------------------- ES8
// Object.values(), Object.entries()

// var person = { id: 1, name: "Manish" };

// // for (const value of Object.values(person)) {
// //     console.log(value);
// // }

// for (const [key, value] of Object.entries(person)) {
//     console.log(key + "\t" + value);
// }

// ---------------------------------------------------- getOwnPropertyDescriptor()

var person = {};

Object.defineProperty(person, "firstname", {
    value: "NA",
    writable: true,
    enumerable: true
});

// console.log(person.firstname);
// person.firstname = "Manish";
// console.log(person.firstname);

var desp = Object.getOwnPropertyDescriptor(person, 'firstname');
console.log(desp);
