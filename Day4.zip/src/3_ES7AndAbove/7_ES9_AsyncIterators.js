// var collection = {
//     [Symbol.iterator]: function* genWithPromise() {
//         const promises = [Promise.resolve({ id: 1 }), Promise.resolve({ id: 2 }), Promise.resolve({ id: 3 })];

//         while(promises.length){
//             yield promises.shift();
//         }
//     }
// }

// for (const item of collection) {
//     // console.log(item);
//     item.then(console.log);
// }

// console.log("Last Line");

// ------------------------------------------- Async Iterator

// function asyncIterator() {
//     const array = [1, 2, 3, 4, 5];
//     return {
//         next: function () {
//             if (array.length) {
//                 return Promise.resolve({
//                     value: array.shift(),
//                     done: false
//                 });
//             } else {
//                 return Promise.resolve({
//                     done: true
//                 });
//             }
//         }
//     };
// }

// var iterator = asyncIterator();

// (async function(){
//     await iterator.next().then(console.log);
//     await iterator.next().then(console.log);
//     await iterator.next().then(console.log);
//     await iterator.next().then(console.log);
//     await iterator.next().then(console.log);
// })();

// var asyncIterable = {
//     [Symbol.asyncIterator]: asyncIterator
// };

// // for-await-of
// (async function () {
//     for await (const item of asyncIterable) {
//         console.log(item);
//     }
// })();

// ------------------------------------------------------- Async Generator
var asyncIterable = {
    [Symbol.asyncIterator]: async function* asyncGenerator() {
        var array = [Promise.resolve(1), Promise.resolve(2), Promise.resolve(3), Promise.resolve(4)];

        while (array.length) {
            yield await array.shift();
        }
    }
};

(async function () {
    for await (const item of asyncIterable) {
        console.log(item);
    }
})();

console.log("Last Line");