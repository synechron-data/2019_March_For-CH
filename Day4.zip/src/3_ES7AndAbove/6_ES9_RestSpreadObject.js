// ES6

// const numbers = [1, 2, 3, 4, 5];
// // var [a, b, ...extras] = numbers;     //Rest
// // console.log(a, b);
// // console.log(extras);

// var sum = function (a, b, c, d, e) {
//     return a + b + c + d + e;
// }

// console.log(sum(...numbers));   //Spread

// ES9 - Object Rest and Spread
var person = { id: 1, name: "Manish", city: "Pune", state: "MH", zip: 411021 };

var { id, name, ...address } = person; // Rest
// console.log(id, name);
// console.log(address);

const data = { ...person, native: "VBN" };      // Spread
console.log(data);