// import './1_Promise/1_CustomPromise';
// import './1_Promise/2_ChainingPromise';
// import './1_Promise/3_PromiseMethods';
// import './1_Promise/4_Assignment';

// import './2_Proxy/1_demo';
// import './2_Proxy/2_demo';
// import './2_Proxy/3_demo';

// import './3_ES7AndAbove/1_ES7_Features';
// import './3_ES7AndAbove/2_ES8_ObjectMethods';
// import './3_ES7AndAbove/3_ES8_StringPadding';
// import './3_ES7AndAbove/4_ES8_TrailingCommas';
// import fMethod from './3_ES7AndAbove/5_ES8_AsyncFn';

// (async function(){
//     var result = await fMethod();
//     console.log(result);
// })();

// import './3_ES7AndAbove/6_ES9_RestSpreadObject';
// import './3_ES7AndAbove/7_ES9_AsyncIterators';
import './3_ES7AndAbove/8_ES9_TemplateLiteral';
