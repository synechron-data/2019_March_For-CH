// let errObj = {
//     code: "0x1001",
//     message: "Just Check you code"
// };

// console.log(errObj.code);
// console.log(errObj.message);
// console.log(errObj.source);

// ------------------------------------ Proxy
// handler - Object which contains a trap
// trap - Methods that provide property access
// target - Object which the proxy is wrapping

// handler.get()
// handler.set()
// handler.deleteProperty()
// handler.apply()
// handler.construct()

let errObj = {
    code: "0x1001",
    message: "Just Check you code"
};

var handler = {
    get: function (target, key) {
        return key in target ? target[key] : 'Property not Found...';
    }
};

let errProxy = new Proxy(errObj, handler);

console.log(errProxy.code);
console.log(errProxy.message);
console.log(errProxy.source);