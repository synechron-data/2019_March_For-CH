function add(x, y) {
    return x + y;
}

const handler = {
    apply: function (target, thisArg, argsList) {
        console.log(thisArg);
        return target(argsList[0], argsList[1]);
    }
};

console.log(add(2, 3));

var proxyAdd = new Proxy(add, handler);
console.log(proxyAdd(2, 3));
console.log(proxyAdd.call(window, 2, 3));
