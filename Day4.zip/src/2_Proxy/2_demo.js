// Proxy means ‘in place of’, representing’ or ‘in place of’ or 
// ‘on behalf of’ are literal meanings of proxy 

// Proxies are also called surrogates, handles, and wrappers.
// Control and manage access to the object they are protecting

var person = { age: 28 };

var handler = {
    set: function (target, key, value) {
        if (key === 'age') {
            if (typeof value != "number" || Number.isNaN(value)) {
                throw ('Age must be a number');
            }
        }

        target[key] = value;
        return true;
    }
}

try {
    var personProxy = new Proxy(person, handler);
    // personProxy.age = "hi";
    personProxy.age = 35;
    console.log(person);
    console.log(personProxy);
}
catch (e) {
    console.error(e);
}