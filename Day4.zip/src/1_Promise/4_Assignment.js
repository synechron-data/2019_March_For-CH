var getUser = function (userId) {
    var promise = new Promise((resolve, reject) => {
        fetch(`https://jsonplaceholder.typicode.com/users/${userId}`).then((response) => {
            var result = response.json();
            result.then(data => {
                resolve(data);
            }).catch(err => {
                reject("JSON Parse Error...");
            })
        }, (err) => {
            reject("Communication Error...");
        });
    });

    return promise;
}

// var getUser = function (userId) {
//     return fetch(`https://jsonplaceholder.typicode.com/users/${userId}`);
// }

var getPostsForUser = function (user) {
    var promise = new Promise((resolve, reject) => {
        fetch(`https://jsonplaceholder.typicode.com/posts?userId=${user.id}`).then((response) => {
            var result = response.json();
            result.then(data => {
                user.posts = data;
                resolve(user);
            }).catch(err => {
                reject("JSON Parse Error...");
            })
        }, (err) => {
            reject("Communication Error...");
        });
    });

    return promise;
}


getUser(4)
    .then(getPostsForUser).then(data => { console.log(data) });