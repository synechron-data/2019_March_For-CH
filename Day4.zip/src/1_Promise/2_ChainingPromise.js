var firstMethod = function () {
    var promise = new Promise((resolve, reject) => {
        setTimeout(function () {
            console.log("First Method Completed....");
            resolve({ data: 1 });
        }, 2000);
    });

    return promise;
}

var secondMethod = function (someData) {
    var promise = new Promise((resolve, reject) => {
        setTimeout(function () {
            console.log("Second Method Completed....");
            resolve({ newData: someData.data + 2 });
        }, 2000);
    });

    return promise;
}

var thirdMethod = function (someData) {
    var promise = new Promise((resolve, reject) => {
        setTimeout(function () {
            console.log("Third Method Completed....");
            resolve({ result: someData.newData + 3 });
        }, 2000);
    });

    return promise;
}

firstMethod()
    .then(secondMethod)
    .then(thirdMethod).then(data => { console.log(data) });

// firstMethod().then(data => { console.log(data) });
// secondMethod().then(data => { console.log(data) });
// thirdMethod().then(data => { console.log(data) });