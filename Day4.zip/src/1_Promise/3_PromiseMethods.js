var firstMethod = function () {
    var promise = new Promise((resolve, reject) => {
        setTimeout(function () {
            console.log("First Method Completed....");
            // resolve({ firstdata: 1 });
            reject("Error in 1st Method..");
        }, 2000);
    });

    return promise;
}

var secondMethod = function () {
    var promise = new Promise((resolve, reject) => {
        setTimeout(function () {
            console.log("Second Method Completed....");
            // resolve({ seconddata: 2 });
            reject("Error in 2nd Method..");
        }, 3000);
    });

    return promise;
}

var thirdMethod = function () {
    var promise = new Promise((resolve, reject) => {
        setTimeout(function () {
            console.log("Third Method Completed....");
            // resolve({ thirddata: 3 });
            reject("Error in 3rd Method..");
        }, 4000);
    });

    return promise;
}

// firstMethod()
//     .then(secondMethod)
//     .then(thirdMethod).then(data => { console.log(data) });

// Promise.all([firstMethod(), secondMethod(), thirdMethod()]).then(data=>{
//     console.log(data);
// }, (err)=>{
//     console.error(err);
// });

Promise.race([firstMethod(), secondMethod(), thirdMethod()]).then(data=>{
    console.log(data);
}, (err)=>{
    console.error(err);
});