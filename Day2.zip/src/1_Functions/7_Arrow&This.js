// function Person() {
//     this.age = 20;

//     this.growOld = function () {
//         console.log(this);
//         this.age += 1;
//     }
// }

// var p1 = new Person();
// console.log(p1.age);
// // console.log(p1);
// p1.growOld();
// p1.growOld();
// p1.growOld();
// console.log(p1.age);

// -----------------------------------------
// setInterval(p1.growOld, 1000);

// setInterval(function () {
//     console.log(p1.age);
// }, 1000);

// -----------------------------------------
// setInterval(p1.growOld.bind(p1), 1000);

// setInterval(function () {
//     console.log(p1.age);
// }, 1000);

// ----------------------------------------- Lexical Closure
// function Person() {
//     var self = this;
//     self.age = 20;

//     self.growOld = function () {
//         self.age += 1;
//     }
// }

// var p1 = new Person();
// setInterval(p1.growOld, 1000);

// setInterval(function () {
//     console.log(p1.age);
// }, 1000);

// ----------------------------------------- Using Arrow
function Person() {
    this.age = 20;

    this.growOld = () => {
        this.age += 1;
    }
}

var p1 = new Person();

setInterval(p1.growOld, 1000);
setInterval(function () {
    console.log(p1.age);
}, 1000);

// In ES5 ‘this’ referred to the parent of the function, 
// In ES6, arrow functions use lexical scoping — ‘this’ refers to it’s current surrounding scope and no further.