// function Check(x, y) {
//     console.log(arguments);
//     console.log(this);
//     console.log(`x: ${x}, y: ${y}`);
// }

// Invoking Fn
// Check();
// Check.call();
// Check.apply();

// Set Context
// Check(2, 3);
// Check.call(window, 2, 3);
// Check.apply(window, [2, 3]);

// var NewCheck = Check.bind(window);
// NewCheck(20, 30);

// ------------------------------------------------------
// var e1 = {
//     id: 1,
//     name: "Manish",
//     display: function () {
//         console.log(JSON.stringify(this));
//     }
// };

// var e2 = {
//     id: 2,
//     name: "Abhijeet",
//     display: function () {
//         console.log(JSON.stringify(this));
//     }
// };

// e1.display();
// e2.display();

// ------------------------------------------------------
// var e1 = {
//     id: 1,
//     name: "Manish"
// };

// var e2 = {
//     id: 2,
//     name: "Abhijeet"
// };

// function display() {
//     console.log(JSON.stringify(this));
// }

// // display.call(e1);
// // display.call(e2);

// e1.dump = display.bind(e1);
// e2.dump = display.bind(e2);

// e1.dump();
// e2.dump();

// ---------------------------------------------

// function Check() {
//     console.log(this);
// }

// Check();

// console.log(this);