// function Converter(toUnit, factor, offset, input) {
//     return [((offset + input) * factor).toFixed(2), toUnit].join("");
// }

// var MilesToKm = Converter.bind(this, ' km', 1.6, 0);
// var PoundsToKg = Converter.bind(this, ' kg', 0.45460, 0);
// var FToC = Converter.bind(this, ' deg C', 0.5556, -32);

function Converter(toUnit, factor, offset) {
    offset = offset || 0;

    return function (input) {
        return [((offset + input) * factor).toFixed(2), toUnit].join("");
    }
}

var MilesToKm = Converter(' km', 1.6);
var PoundsToKg = Converter(' kg', 0.45460);
var FToC = Converter(' deg C', 0.5556, -32);

console.log(MilesToKm(10));
console.log(MilesToKm(100));
console.log(MilesToKm(47));
console.log(PoundsToKg(3));
console.log(FToC(98));