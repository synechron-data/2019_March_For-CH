// function greetings(message, name) {
//     console.log(`${message}, ${name}`);
// }

// greetings("Good Morning", "Abhijeet");
// greetings("Good Morning", "Ramakant");
// greetings("Good Morning", "Subodh");

// ---------------------------------------------------------
// function greetings(message) {
//     return function (name) {
//         console.log(`${message}, ${name}`);
//     }
// }

// var mGreet = greetings("Good Morning");
// mGreet("Abhijeet");
// mGreet("Ramakant");
// mGreet("Subodh");

// ---------------------------------------------------------
function greetings(message, name) {
    console.log(`${message}, ${name}`);
}

var mGreet = greetings.bind(this, "Good Morning");
mGreet("Abhijeet");
mGreet("Ramakant");
mGreet("Subodh");
