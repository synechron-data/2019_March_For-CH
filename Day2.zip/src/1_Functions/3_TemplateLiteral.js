var name = "Manish";
var message = "How are you?";

// ES 5
// var fMsg = "Hello " + name +  ", " + message;
// console.log(fMsg);

// ES 2015 
// var fMsg = `Hello ${name}, ${message}`;
// console.log(fMsg);

var fMsg = `Hello 


${name}, 

            ${message}`;
            
console.log(fMsg);