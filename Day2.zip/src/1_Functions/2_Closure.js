// var count = 0;

// function Next() {
//     return count += 1;
// }

// console.log(Next());
// count = "ABC";
// console.log(Next());
// console.log(Next());

// --------------------------------------

// function Next() {
//     var count = 0;
//     return count += 1;
// }

// console.log(Next());
// console.log(Next());
// console.log(Next());

// --------------------------------------

// var Next = (function () {
//     var count = 0;

//     return function () {
//         return count += 1;
//     }
// })();

// console.log(Next());
// console.log(Next());
// console.log(Next());
// console.log(Next());

// ----------------------------------------

// var counter = (function () {
//     var count = 0;

//     return {
//         next: function () {
//             return count += 1;
//         },
//         prev: function () {
//             return count -= 1;
//         }
//     };
// })();

// console.log(counter.next());
// console.log(counter.next());
// console.log(counter.prev());
// console.log(counter.next());

// ----------------------------------------

function CounterFactory(interval) {
    var count = 0;

    return {
        next: function () {
            return count += interval;
        },
        prev: function () {
            return count -= interval;
        }
    };
};

console.log("Counter 5");
var counter5 = CounterFactory(5);
console.log(counter5.next());
console.log(counter5.next());
console.log(counter5.prev());
console.log(counter5.next());

console.log("Counter 20");
var counter20 = CounterFactory(20);
console.log(counter20.next());
console.log(counter20.next());
console.log(counter20.prev());
console.log(counter20.next());
