// import './1_Functions/1_Assignment';
// import './1_Functions/2_Closure';
// import './1_Functions/3_TemplateLiteral';
// import './1_Functions/4_FnInvocation';
// import './1_Functions/5_FnCurrying';
// import './1_Functions/6_Assignment';
// import './1_Functions/7_Arrow&This';

// import './2_Types/1_ObjectLiteral';
// import './2_Types/2_ObjectType';
// import './2_Types/3_ObjectMethods';
// import './2_Types/4_CustomType';
// import './2_Types/5_UsingPrototype';
// import './2_Types/6_Assignment';
// import './2_Types/7_ES6_Class';
import './2_Types/8_Compare';

// import './3_Modules/usage';