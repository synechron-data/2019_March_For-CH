// let target = { a: 1, b: 2 };
// let source = { id: 1, name: "Manish", address: { city: "Pune" } };

// // let obj = Object.assign({}, source);
// // console.log(obj);

// // let obj1 = Object.assign(target, source);
// // console.log(obj1);

// // console.log(target);

// // let obj = Object.assign({}, source);

// // console.log("Source: ", source);
// // console.log("obj: ", obj);

// // obj.id = 100;
// // obj.address.city = "Mumbai";

// // console.log("Source: ", source);
// // console.log("obj: ", obj);

// // var obj = { ...source };   // Object Spread

// var obj = JSON.parse(JSON.stringify(source));

// console.log("Source: ", source);
// console.log("obj: ", obj);

// obj.id = 100;
// obj.address.city = "Mumbai";

// console.log("Source: ", source);
// console.log("obj: ", obj);

// ------------------------------------------ Object.create
// Creates a new object, using an existing object as the prototype of the newly created object.
// let source = { id: 1, name: "Manish", address: { city: "Pune" } };

// const newSource = Object.create(source);

// console.log("Source: ", source);
// console.log("newSource: ", newSource);

// ------------------------------------------- Object.freeze
// let source = { id: 1, name: "Manish" };

// console.log(source);
// // Object.freeze(source);
// Object.preventExtensions(source)
// console.log(Object.isExtensible(source));

// if (Object.isExtensible(source)) {
//     source.city = "Pune";
//     console.log(source);
// }

// ------------------------------------------------

const person = { id: 1, name: "Manish" };
console.log(person);
person.id = 100;
console.log(person);

Object.freeze(person);
person.city = "Pune";
console.log(person);

// person = {};