class Counter {
    constructor(interval) {
        this._count = 0;
        this._interval = interval;
    }

    next() {
        return this._count += this._interval;
    }

    prev() {
        return this._count -= this._interval;
    }
}

console.log("Counter 5");
var counter5 = new Counter(5);
console.log(counter5.next());
console.log(counter5.next());
console.log(counter5.prev());
console.log(counter5.next());

console.log("Counter 20");
var counter20 = new Counter(20);
console.log(counter20.next());
console.log(counter20.next());
console.log(counter20.prev());
console.log(counter20.next());