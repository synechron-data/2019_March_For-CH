// var toy1 = new Object();
// console.log(toy1.toString());
// console.log(toy1);
// console.log(typeof toy1);

// toy1.color = 'red';
// toy1.shape = 'circular';
// console.log(toy1);

// var toy2 = new Object();
// console.log(toy2);

var toy1 = new Object();
var toy2 = new Object();

Object.prototype.color = 'red';

console.log("Toy1: ", toy1.color);
console.log("Toy2: ", toy2.color);

toy1.color = "green";
console.log("Toy1: ", toy1.color);
console.log("Toy2: ", toy2.color);


