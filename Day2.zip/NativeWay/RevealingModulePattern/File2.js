var calculator = (function () {
    function Mod(x, y) {
        return x % y;
    }

    return { Mod };
})();

