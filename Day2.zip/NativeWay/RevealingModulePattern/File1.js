var calculator = (function () {
    function Add(x, y) {
        return x + y;
    }

    function Sub(x, y) {
        return x - y;
    }

    function Mul(x, y) {
        return x * y;
    }

    function Div(x, y) {
        return x / y;
    }

    // return {
    //     Add: Add,
    //     Subtract: Sub,
    //     Mul: Mul
    // };

    // return {
    //     Add: Add,
    //     Sub: Sub,
    //     Mul: Mul
    // };

    // EX 2015 (ES6) - Shortcut of Object Literal
    return { Add, Sub, Mul };
})();

// console.log(calculator);
// console.log(calculator.Add(2, 5));
// console.log(calculator.Sub(2, 5));

// var Add = calculator.Add;
// var Sub = calculator.Sub;

// ES6 - Object Destructuring

// var { Add, Sub } = calculator;

// console.log(Add(2, 5));
// console.log(Sub(2, 5));

// ------------------------------------- ES6 - Array Destructuring

var arr = [10, 20, 30, 40, 50];

// var x = arr[0];
// var y = arr[1];

// var [x, , y] = arr;
// console.log("x is: " + x + ", y is: " + y);

var [x, , y] = arr;

// console.log("Before, x is: " + x + ", y is: " + y);
// [x, y] = [y, x];
// console.log("After, x is: " + x + ", y is: " + y);

console.log(`Before, x is: ${x}, y is: ${y}`);
[x, y] = [y, x];
console.log(`After, x is: ${x}, y is: ${y}`);
