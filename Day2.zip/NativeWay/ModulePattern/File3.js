var dev1;

(function (ns) {
    function NewMethod() {
        console.log("Check from File 1");
    }

    ns.NewMethod = NewMethod;
})(dev1 = dev1 || {});
