var dev1;

(function (ns) {
    function LocalCheck() {
        console.log("Check from File 1");
    }

    ns.Check = LocalCheck;
})(dev1 = dev1 || {});
