var dev2;

(function (ns) {
    var Check = 1;
    
    ns.Check = Check;
})(dev2 = dev2 || {});
