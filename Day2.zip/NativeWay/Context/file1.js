// function Check() {
//     console.log(arguments);
//     console.log(this);
// }

// Check();


// (function () {
//     function Check() {
//         console.log(this);
//     }

//     Check();
// })();

var dev1;

(function (ns) {
    function LocalCheck() {
        console.log(this);
        console.log("Check from File 1");
    }

    ns.Check = LocalCheck;
})(dev1 = dev1 || {});


dev1.Check();
console.log(this);